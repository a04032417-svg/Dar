// Dar WhatsApp gateway (v3.32) — WhatsApp linked by QR code or by a pairing code, for Dar's developer and for each subscriber.
// The owner (2026-10-21): «الان التفعيل سيكون من خلال الباركود» and «تجربة node.js مع بناء آلية تمنع التوقف والخمول مثل التنشيط المستمر».
//  · one WhatsApp session per Dar account (its id: «platform» for the developer, the account's id for a subscriber), each one
//    isolated: its own folder, its own keys sealed at rest (AES-256-GCM, a key per session), never two sockets for one session;
//  · Dar speaks to it over HTTPS, every request signed with the shared secret (HMAC-SHA256 over time, nonce, method, path and the
//    body's hash; five minutes' grace; a nonce once): start a session (QR or pairing code), its state, log out, send (text, image,
//    document, voice, video, location, contact, reaction, reply, a poll of one or several answers), a WhatsApp Status for a list
//    of numbers, typing, read, check numbers, groups, archive, pin, mute, block;
//  · what happens reaches Dar through a durable outbox (lib/outbox.mjs): messages in (and those written from the phone), delivery
//    reports, the votes on its polls, sessions linked or lost — signed, in order, retried until Dar takes them; and while a number
//    is linked, a signed «tick» each minute (Dar's scheduled messages and campaigns leave on it, to the minute);
//  · it stays up: sessions come back by themselves after a restart; a dropped connection is reopened with growing waits; a
//    logged-out session's keys are kept aside seven days (never deleted on a failure); the gateway pings its own public address
//    every four minutes (a host that idles quiet apps keeps it awake) and Dar's scheduled job pings it too;
//  · the shared secret reaches Dar by a pairing that only Dar's own address (DAR_ORIGIN) can complete: nothing secret is shown in a
//    browser or passed in a link.
// Environment: PORT, DAR_ORIGIN (https://dar.ink), GW_SECRET, GW_MASTER_KEY (base64, 32 bytes), GW_DATA_DIR (default ~/.dar-wa),
// PUBLIC_URL (this gateway's own https address), GW_DAILY_CAP (messages a session may send a day, default 1000),
// GW_TG_DAILY_CAP (v1.1.0: messages the developer's own Telegram account may send a day, default 300 — lib/tg.mjs).
import http from 'node:http';
import { homedir, hostname } from 'node:os';
import { join } from 'node:path';
import { mkdir, readFile, writeFile, rename, stat, unlink, readdir } from 'node:fs/promises';
import { watch } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { randomBytes, createHmac, createHash, timingSafeEqual } from 'node:crypto';
import { useSealedAuthState, listSessions, hasCreds, retire, cleanTrash, validSid, seal, open } from './lib/store.mjs';
import { makeOutbox, signHeaders } from './lib/outbox.mjs';
import { makeContacts } from './lib/contacts.mjs';
import { makeTelegram } from './lib/tg.mjs';

const VERSION = '1.1.1';
const env = process.env;
const ROOT = env.GW_DATA_DIR || join(homedir(), '.dar-wa');
const ORIGIN = String(env.DAR_ORIGIN || '').replace(/\/+$/, '');
const HOOK = env.DAR_HOOK || (ORIGIN ? ORIGIN + '/dar-sync.php?wag=1' : '');
const PAIR_HOOK = ORIGIN ? ORIGIN + '/dar-sync.php?wag=pair' : '';
const DAILY_CAP = Math.max(10, +(env.GW_DAILY_CAP || 1000));
const TICK = Math.max(200, +(env.GW_TICK_MS || 20e3)), STALE = Math.max(TICK * 2, +(env.GW_STALE_MS || 60e3)); // (the runner's heartbeat; tests shorten them)
const FAKE = env.GW_FAKE === '1';
const log = (...a) => { if (env.GW_QUIET !== '1') console.log(new Date().toISOString(), ...a); };
const B = FAKE ? await import('./test/fake-baileys.mjs') : await import('baileys');
const makeWASocket = B.default || B.makeWASocket;
const { DisconnectReason, Browsers, jidNormalizedUser, getContentType, normalizeMessageContent, downloadMediaMessage, makeCacheableSignalKeyStore, generateMessageIDV2, getAggregateVotesInPollMessage } = B;

// ---------------------------------------------------------------- the gateway's own keys (from the host's environment; kept sealed on disk otherwise)
await mkdir(ROOT, { recursive: true, mode: 0o700 });
async function persistent(name, make) {
  const p = join(ROOT, name); try { const v = (await readFile(p, 'utf8')).trim(); if (v) return v; } catch { /* first start */ }
  const v = make(); const tmp = p + '.tmp'; await writeFile(tmp, v, { mode: 0o600 }); await rename(tmp, p); return v;
}
const MASTER = Buffer.from(env.GW_MASTER_KEY || await persistent('_master', () => randomBytes(32).toString('base64')), 'base64');
if (MASTER.length !== 32) { console.error('GW_MASTER_KEY must be 32 bytes in base64'); process.exit(1); }
let SECRET = env.GW_SECRET || await persistent('_secret', () => randomBytes(32).toString('hex'));
const OUTKEY = createHash('sha256').update(Buffer.concat([MASTER, Buffer.from('outbox')])).digest();
const outbox = makeOutbox({ root: ROOT, key: OUTKEY, target: () => (RUNNER ? HOOK : ''), secret: () => SECRET, log }); // (only the runner delivers)

// ---------------------------------------------------------------- v1.1.0: the developer's own Telegram account (lib/tg.mjs), loaded when first needed
let TG = null;
async function tg() {
  if (TG) return TG; let L;
  try {
    if (FAKE) L = await import('./test/fake-telegram.mjs');
    else { const m = await import('teleproto'); L = { TelegramClient: m.TelegramClient, Api: m.Api, utils: m.utils, StringSession: m.sessions.StringSession, NewMessage: m.events.NewMessage }; }
  } catch (e) { log('telegram library', e.message); return null; }
  TG = makeTelegram({ root: ROOT, master: MASTER, emit, log, lib: L, dailyCap: Math.max(10, +(env.GW_TG_DAILY_CAP || 300)) }); return TG;
}
const tgSaved = async () => { try { return (await readdir(join(ROOT, '_tg'))).some(x => x.endsWith('.enc')); } catch { return false; } };

// ---------------------------------------------------------------- one runner (never two sockets for one session)
// A host may run this app as several processes (a pool that starts one on a request and stops a quiet one; it may also take
// over every «listen» of the app, so the processes cannot open addresses of their own). One of them — the runner — holds the
// WhatsApp sessions and writes «_runner» every 20 seconds. Any other process answers the health and the pairing itself and hands
// every signed request to the runner, unchanged, through the data folder (a request file, its answer file — «_rpc»). A runner
// that is stopped lets go at once (its sessions closed, not logged out); one that vanished is replaced a minute later; a newer
// version asks the older one to hand over (it closes its sessions first) — so two sockets never serve one session.
const BUILD = env.GW_BUILD || await (async () => { try { return String(Math.round((await stat(fileURLToPath(import.meta.url))).mtimeMs)); } catch { return '0'; } })(); // (the code's own date: a new upload is a newer build)
const ME = { pid: process.pid, id: randomBytes(6).toString('hex'), host: hostname(), v: VERSION, build: BUILD, started: Date.now(), rpc: 'file' };
let RUNNER = false; let HOLDER = null; let BOOT = 'waiting';
const LOCK = join(ROOT, '_runner'), HANDOVER = join(ROOT, '_handover'), RPC = join(ROOT, '_rpc');
const pidAlive = (pid, host) => { if (host && host !== ME.host) return true; try { process.kill(+pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
async function readJson(p) { try { return JSON.parse(await readFile(p, 'utf8')); } catch { return null; } }
async function writeJson(p, v) { const tmp = p + '.' + ME.id; await writeFile(tmp, JSON.stringify(v), { mode: 0o600 }); await rename(tmp, p); }
async function claimRunner() {
  const cur = await readJson(LOCK);
  const live = cur && cur.rpc && cur.id !== ME.id && Date.now() - (+cur.at || 0) < STALE && pidAlive(cur.pid, cur.host); // (a holder that cannot take requests from the others is an older version: taken over, it steps back by itself)
  if (live) {
    if (cur.v !== ME.v || cur.build !== ME.build) await writeJson(HANDOVER, { id: ME.id, v: ME.v, build: ME.build, at: Date.now() }).catch(() => {}); // (newer code asks the older to hand over)
    RUNNER = false; HOLDER = cur; return false;
  }
  await writeJson(LOCK, { ...ME, at: Date.now() }); RUNNER = true; HOLDER = null; return true;
}
// the runner lets go: its sessions closed (never logged out), the lock freed for the next process
async function standDown(why) {
  if (!RUNNER) return; log('handing over:', why); RUNNER = false;
  for (const s of S.values()) { s.handover = true; try { s.sock?.end?.(undefined); } catch { /* closing */ } s.sock = null; }
  S.clear(); if (TG) await TG.close().catch(() => {}); const cur = await readJson(LOCK); if (cur?.id === ME.id) await writeJson(LOCK, { ...cur, at: 0 }).catch(() => {});
}
async function runnerTick() {
  if (RUNNER) {
    const h = await readJson(HANDOVER);
    if (h && h.id !== ME.id && Date.now() - (+h.at || 0) < STALE && (h.v !== ME.v || h.build !== ME.build)) { await standDown('a newer version (' + h.v + ')'); await unlink(HANDOVER).catch(() => {}); return; }
    const cur = await readJson(LOCK); if (cur && cur.rpc && cur.id !== ME.id && Date.now() - (+cur.at || 0) < STALE) { await standDown('another runner took the lock'); return; }
    await writeJson(LOCK, { ...ME, at: Date.now() }).catch(() => {}); return;
  }
  if (await claimRunner()) await restoreAll();
}
async function restoreAll() { for (const sid of await listSessions(ROOT)) if (!S.has(sid) && await hasCreds(ROOT, sid)) startSession(sid, { mode: 'qr' }).catch(e => log(sid, 'restore', e.message)); if (await tgSaved()) (await tg())?.restore().catch(e => log('tg restore', e.message)); } // (linked sessions come back by themselves — the Telegram account too)

// ---------------------------------------------------------------- sessions
const S = new Map(); // sid → session
const lru = (max) => { const m = new Map(); return { get: k => m.get(k), has: k => m.has(k), set: (k, v) => { m.delete(k); m.set(k, v); if (m.size > max) m.delete(m.keys().next().value); }, keys: () => [...m.keys()] }; };
const digitsOf = jid => { const x = String(jid || '').split('@')[0].split(':')[0]; return /^\d{6,16}$/.test(x) ? x : ''; };
const toJid = to => { const s = String(to || '').trim(); if (/@/.test(s)) return s; const d = s.replace(/\D/g, ''); return d.length >= 8 && d.length <= 15 ? d + '@s.whatsapp.net' : ''; };
const norm = j => (jidNormalizedUser ? jidNormalizedUser(j) : j);
// a person WhatsApp shows only by his private id (no number given): his messages come from «…@lid», and the answers go back there.
// Dar knows him by those digits; the session remembers which digits are such ids (sealed on disk, so a restart forgets nothing)
const jidFor = (s, to) => { const j = toJid(to); if (!j) return ''; const d = j.split('@')[0]; return j.endsWith('@s.whatsapp.net') && s.lids?.has(d) ? d + '@lid' : j; };
function saveLids(s) { clearTimeout(s.lidT); s.lidT = setTimeout(() => { s.auth?.extra?.write('lids.json', [...s.lids].slice(-5000)).catch(() => {}); }, 1500); }
async function pnOf(s, jid) { // (the number behind a private id, when WhatsApp told this session — Baileys keeps the mapping)
  if (!/@lid$/.test(jid)) return jid;
  try { const pn = await s.sock?.signalRepository?.lidMapping?.getPNForLID?.(jid); if (pn) return norm(pn); } catch { /* unknown */ }
  return jid;
}
const evId = (sid, kind, x) => createHash('sha256').update(sid + '|' + kind + '|' + x).digest('hex').slice(0, 24);
function emit(sid, type, data, id = '') { return outbox.push({ id: id || evId(sid, type, randomBytes(8).toString('hex')), sid, type, data, at: Date.now(), v: VERSION }); }
function pub(s) { return { sid: s.sid, status: s.status, mode: s.mode, me: s.me, qr: s.status === 'qr' ? s.qr : '', code: s.status === 'code' ? s.code : '', since: s.since, last_seen: s.lastSeen, reason: s.reason || '', sent_today: s.day.n }; }
// Dar is told what lasts: linked, lost (and why); a connection that drops and comes back within a minute is not news
const SAY = ['open', 'logged_out', 'banned', 'replaced', 'expired', 'error'];
function setStatus(s, status, reason = '') {
  const was = s.status; s.status = status; s.reason = reason; s.since = was === status ? s.since : Date.now();
  if (was !== status && SAY.includes(status) && !(status === 'open' && s.said === 'open')) { s.said = status; emit(s.sid, 'session.status', { status, reason, me: s.me }); }
  if (was !== status && status === 'reconnecting' && s.said === 'open') { const at = s.since; setTimeout(() => { if (s.status === 'reconnecting' && s.since === at) { s.said = 'reconnecting'; emit(s.sid, 'session.status', { status: 'reconnecting', reason: s.reason, me: s.me }); } }, 60e3).unref(); }
  s.meta?.write({ status, mode: s.mode, me: s.me, at: Date.now() }).catch(() => {});
}
async function startSession(sid, { mode = 'qr', phone = '' } = {}) {
  if (!validSid(sid)) throw Object.assign(new Error('bad session id'), { code: 400 });
  let s = S.get(sid);
  if (s?.sock && ['open', 'connecting', 'qr', 'code', 'starting', 'reconnecting'].includes(s.status)) {
    if (mode === 'code' && phone && s.status === 'qr' && !s.code) await askCode(s, phone).catch(() => {});
    return s;
  }
  const auth = await useSealedAuthState(ROOT, sid, MASTER);
  s = s || { sid, sent: lru(2000), store: lru(300), seen: lru(2000), day: { d: '', n: 0 }, tries: 0, queue: Promise.resolve() };
  Object.assign(s, { auth, meta: auth.meta, mode, phone: String(phone || '').replace(/\D/g, ''), qr: '', code: '', me: s.me || null, lastSeen: s.lastSeen || 0 });
  const m0 = await auth.meta.read(); if (m0?.me && !s.me) s.me = m0.me;
  s.contacts = makeContacts(auth.extra, { log: (...a) => log(sid, ...a) }); await s.contacts.load(); // v1.0.6: the phone's address book (names), kept sealed
  if (!s.lids) { const l = await auth.extra.read('lids.json'); s.lids = new Set(Array.isArray(l) ? l.map(String) : []); }
  S.set(sid, s); setStatus(s, 'starting');
  const sock = makeWASocket({
    auth: { creds: auth.state.creds, keys: makeCacheableSignalKeyStore ? makeCacheableSignalKeyStore(auth.state.keys, silent) : auth.state.keys }, logger: silent,
    browser: Browsers?.macOS ? Browsers.macOS('Dar') : ['Dar', 'Chrome', VERSION], markOnlineOnConnect: false, syncFullHistory: false, keepAliveIntervalMs: 25e3, connectTimeoutMs: 45e3, defaultQueryTimeoutMs: 60e3,
    getMessage: async key => s.store.get(key.id)?.message || s.sent.get(key.id)?.message || (await s.auth?.extra?.read('p_' + key.id).catch(() => null))?.message || undefined, // (a poll's own message, kept on disk: its votes are read with it)
  });
  s.sock = sock;
  sock.ev.on('creds.update', () => { s.saving = auth.saveCreds().catch(e => log(sid, 'creds', e.message)); }); // (kept: a restart after the scan waits for it)
  sock.ev.on('connection.update', u => onConnection(s, sock, u).catch(e => log(sid, 'conn', e.message)));
  sock.ev.on('messages.upsert', ({ messages, type }) => { for (const m of messages || []) onMessage(s, m, type).catch(e => log(sid, 'msg', e.message)); });
  sock.ev.on('messaging-history.set', h => { try { for (const c of h?.contacts || []) s.contacts.upsert(c); for (const c of h?.chats || []) if (c?.name) s.contacts.upsert({ id: c.id, name: c.name }); } catch (e) { log(sid, 'contacts', e.message); } onHistory(s, h).catch(e => log(sid, 'history', e.message)); }); // v1.0.5: the chats the phone already has (v1.0.6: and the names it knows)
  sock.ev.on('contacts.upsert', cs => { try { for (const c of cs || []) s.contacts.upsert(c); } catch (e) { log(sid, 'contacts', e.message); } }); // v1.0.6: the address book, as WhatsApp's app-state sync gives it
  sock.ev.on('contacts.update', cs => { try { for (const c of cs || []) s.contacts.upsert(c); } catch (e) { log(sid, 'contacts', e.message); } });
  sock.ev.on('lid-mapping.update', x => { try { if (x?.lid && x?.pn) s.contacts.mapLid(x.lid, x.pn); } catch (e) { log(sid, 'contacts', e.message); } });
  sock.ev.on('messages.update', ups => { for (const u of ups || []) { onUpdate(s, u); if (u?.update?.pollUpdates?.length) onPoll(s, u).catch(e => log(sid, 'poll', e.message)); } });
  sock.ev.on('messages.reaction', rs => { for (const r of rs || []) emit(sid, 'reaction', { id: r.key?.id, chat: r.key?.remoteJid, text: r.reaction?.text || '', from: jidNormalizedUser?.(r.reaction?.key?.participant || r.reaction?.key?.remoteJid || '') || '' }); });
  sock.ev.on('call', calls => { for (const c of calls || []) if (c.status === 'offer') emit(sid, 'call', { from: digitsOf(c.from) || c.from, video: !!c.isVideo, at: Date.now() }, evId(sid, 'call', c.id)); });
  return s;
}
const silent = { level: 'silent', child() { return silent; }, trace() {}, debug() {}, info() {}, warn() {}, error() {}, fatal() {} };
// v1.0.6: ask WhatsApp for the whole address book again (the «contact» entries of its critical app-state collection, fetched from a snapshot):
// a session linked before this version never had them. Each name arrives as a contacts.upsert; what could not be fetched is said, never hidden.
async function syncContacts(s, force = false) {
  const sock = s.sock; if (!s.contacts) return { ok: false, why: 'no store' }; if (!sock) return { ok: false, why: 'the session has no socket' }; if (s.status !== 'open') return { ok: false, why: 'the session is not open (' + s.status + ')' }; if (typeof sock.resyncAppState !== 'function') return { ok: false, why: 'this WhatsApp library cannot ask for the contacts' };
  if (!force && s.contacts.st.syncedAt && Date.now() - s.contacts.st.syncedAt < 7 * 864e5) return { ok: true, skipped: true };
  if (s.csync) return s.csync;
  s.csync = (async () => {
    try {
      await sock.authState?.keys?.set?.({ 'app-state-sync-version': { critical_unblock_low: null } }); // (forget the version: WhatsApp then sends the whole collection)
      await sock.resyncAppState(['critical_unblock_low'], true); await pause(1500);
      s.contacts.st.syncedAt = Date.now(); s.contacts.st.error = ''; await s.contacts.flush(); return { ok: true };
    } catch (e) { s.contacts.st.error = String(e?.message || e).slice(0, 160); log(s.sid, 'contacts', 'sync ' + s.contacts.st.error); return { ok: false, why: s.contacts.st.error }; }
    finally { s.csync = null; }
  })();
  return s.csync;
}
async function askCode(s, phone) {
  const d = String(phone).replace(/\D/g, ''); if (d.length < 8 || d.length > 15) throw Object.assign(new Error('phone number'), { code: 400 });
  const code = await s.sock.requestPairingCode(d); s.code = String(code || '').replace(/(.{4})(?=.)/, '$1-'); s.mode = 'code'; setStatus(s, 'code'); return s.code;
}
async function onConnection(s, sock, u) {
  if (s.sock !== sock) return; // (an older socket of this session)
  if (u.qr) {
    if (s.mode === 'code' && s.phone && !s.code) { try { await askCode(s, s.phone); } catch (e) { s.reason = e.message; } }
    if (s.mode !== 'code') { s.qr = u.qr; s.qrAt = Date.now(); setStatus(s, 'qr'); }
  }
  if (u.connection === 'connecting' && s.status !== 'qr' && s.status !== 'code') setStatus(s, s.tries ? 'reconnecting' : 'connecting');
  if (u.connection === 'open') {
    const me = sock.user || {}; const pn = jidNormalizedUser?.(me.id || '') || me.id || '';
    s.me = { id: pn, phone: digitsOf(pn), name: me.name || me.verifiedName || me.notify || '', lid: me.lid || '' }; s.qr = ''; s.code = ''; s.tries = 0; s.replacedN = 0; s.lastSeen = Date.now();
    setStatus(s, 'open');
    if (s.contacts && !s.csyncTimer && (!s.contacts.st.syncedAt || Date.now() - s.contacts.st.syncedAt > 7 * 864e5)) { s.csyncTimer = setTimeout(() => { s.csyncTimer = null; syncContacts(s).catch(e => log(s.sid, 'contacts', e.message)); }, +env.GW_CONTACTS_DELAY_MS || 25e3); s.csyncTimer.unref?.(); } // v1.0.6: the address book, asked from the phone once a week
  }
  if (u.connection === 'close') {
    const code = u.lastDisconnect?.error?.output?.statusCode ?? u.lastDisconnect?.error?.statusCode ?? 0; const R = DisconnectReason || {};
    s.sock = null;
    if (code === R.loggedOut) { setStatus(s, 'logged_out', 'logged out from the phone'); await retire(ROOT, s.sid); s.auth = null; return; }
    if (s.handover || !RUNNER) return; // (this process handed its sessions over: nothing to tell)
    if (code === R.connectionReplaced) { // (the same keys opened elsewhere: another process of ours that should not run them — this runner keeps them)
      const cur = await readJson(LOCK); if (cur && cur.id !== ME.id && Date.now() - (+cur.at || 0) < STALE) { await standDown('replaced by the runner ' + cur.id); return; }
      s.replacedN = (s.replacedN || 0) + 1; if (s.replacedN > 3) { setStatus(s, 'replaced', 'opened elsewhere'); return; }
      setStatus(s, 'reconnecting', 'opened elsewhere — taking it back'); setTimeout(() => { if (!s.sock && RUNNER) startSession(s.sid, { mode: s.mode }).catch(() => {}); }, 15e3); return;
    }
    if (code === R.forbidden) { setStatus(s, 'banned', 'refused by WhatsApp (403)'); return; }
    // v1.0.4 (live, 2026-10-23 — the owner scanned his office's code: «انتهت مهلة الرمز» on the site, «فشل التحميل» on his phone):
    // right after a scan WhatsApp closes the socket asking for a restart (515) — the session is linked (its keys hold the phone's
    // account) but not open yet and still «qr»; it was called «expired» and dropped, so the phone's linking failed. The restart comes
    // first, once the new keys are on disk; a session whose keys name the phone is never «expired»
    if (code === R.restartRequired) { s.tries = 0; const go = () => startSession(s.sid, { mode: s.mode }).catch(e => log(s.sid, 'restart', e.message)); return void Promise.resolve(s.saving).then(go, go); }
    const linked = !!s.auth?.state?.creds?.me?.id;
    if (!linked && (code === R.timedOut || code === 408 || s.status === 'qr' || s.status === 'code')) { setStatus(s, 'expired', 'the code was not scanned in time'); return; }
    s.tries++; const wait = Math.min(60e3, 2e3 * 2 ** Math.min(5, s.tries - 1)); setStatus(s, 'reconnecting', 'closed (' + code + '), again in ' + Math.round(wait / 1000) + 's');
    if (s.tries > 12 && code === R.badSession) { setStatus(s, 'error', 'bad session: link again'); return; }
    setTimeout(() => { if (!s.sock && s.status === 'reconnecting') startSession(s.sid, { mode: s.mode }).catch(e => log(s.sid, 'reconnect', e.message)); }, wait);
  }
}
// a message: what it says, who wrote it (the phone number when WhatsApp gives it: v7's «Alt» addresses), the chat, a reply it quotes
function contentOf(m) {
  const msg = normalizeMessageContent ? normalizeMessageContent(m.message) : m.message; if (!msg) return null; const t = getContentType ? getContentType(msg) : Object.keys(msg)[0]; const x = msg[t] || {};
  const out = { type: 'text', text: '' };
  if (t === 'conversation') out.text = String(msg.conversation || '');
  else if (t === 'extendedTextMessage') out.text = String(x.text || '');
  else if (['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage', 'documentWithCaptionMessage'].includes(t)) {
    out.type = { imageMessage: 'image', videoMessage: 'video', audioMessage: x.ptt ? 'voice' : 'audio', documentMessage: 'document', stickerMessage: 'sticker', documentWithCaptionMessage: 'document' }[t];
    out.caption = String(x.caption || ''); out.mime = String(x.mimetype || ''); out.filename = String(x.fileName || ''); out.size = +x.fileLength || 0; out.seconds = +x.seconds || 0; out.media = true;
  } else if (t === 'locationMessage' || t === 'liveLocationMessage') { out.type = 'location'; out.location = { lat: +x.degreesLatitude, lng: +x.degreesLongitude, name: String(x.name || ''), address: String(x.address || '') }; }
  else if (t === 'contactMessage') { out.type = 'contact'; out.text = String(x.displayName || ''); out.vcard = String(x.vcard || '').slice(0, 4000); }
  else if (t === 'contactsArrayMessage') { out.type = 'contact'; out.text = (x.contacts || []).map(c => c.displayName).join(', '); }
  else if (t === 'reactionMessage') { out.type = 'reaction'; out.text = String(x.text || ''); out.target = x.key?.id || ''; }
  else if (t === 'pollCreationMessage' || t === 'pollCreationMessageV3') { out.type = 'poll'; out.text = String(x.name || ''); out.options = (x.options || []).map(o => o.optionName); }
  else if (t === 'buttonsResponseMessage') { out.text = String(x.selectedDisplayText || ''); out.button = String(x.selectedButtonId || ''); }
  else if (t === 'listResponseMessage') { out.text = String(x.title || ''); out.button = String(x.singleSelectReply?.selectedRowId || ''); }
  else if (t === 'templateButtonReplyMessage') { out.text = String(x.selectedDisplayText || ''); out.button = String(x.selectedId || ''); }
  else if (t === 'protocolMessage') { out.type = x.type === 0 ? 'revoke' : 'protocol'; out.target = x.key?.id || ''; }
  else { out.type = 'other'; out.text = ''; }
  const ci = x.contextInfo || msg.extendedTextMessage?.contextInfo; if (ci?.stanzaId) out.quoted = { id: ci.stanzaId, from: digitsOf(ci.participant) || ci.participant || '', text: String(ci.quotedMessage?.conversation || ci.quotedMessage?.extendedTextMessage?.text || '').slice(0, 500) };
  return out;
}
// v1.0.5 (the owner, 2026-10-23: «يجب ان يظهر الواتساب كأنه فاتحه بجهازك بالضبط»): as WhatsApp on a new device, the chats the phone
// already has come with the link — WhatsApp sends them once (in parts); each person's chat (never a group, a status or a channel), its
// last HIST_PER messages of the last HIST_DAYS days, at most HIST_MAX in all; Dar keeps them as they were (no reply, no notice)
const HIST_DAYS = 30, HIST_PER = 30, HIST_MAX = 2000;
async function onHistory(s, h) {
  const since = Date.now() - HIST_DAYS * 864e5; s.hist = s.hist || { n: 0, per: new Map(), names: new Map() };
  for (const c of h?.contacts || []) { const id = norm(String(c.id || '')); const nm = String(c.name || c.notify || c.verifiedName || ''); if (id && nm) s.hist.names.set(id, nm); }
  for (const c of h?.chats || []) { const id = norm(String(c.id || '')); const nm = String(c.name || ''); if (id && nm && !s.hist.names.has(id)) s.hist.names.set(id, nm); }
  const byChat = new Map();
  for (const m of h?.messages || []) {
    const chat = m?.key?.remoteJid || ''; if (!m?.key?.id || !chat || /@(g\.us|broadcast|newsletter)$/.test(chat) || chat === 'status@broadcast') continue;
    const at = (+m.messageTimestamp || 0) * 1000; if (!at || at < since) continue;
    if (!byChat.has(chat)) byChat.set(chat, []); byChat.get(chat).push(m);
  }
  for (const [chat, list] of byChat) {
    const room = HIST_PER - (s.hist.per.get(chat) || 0); if (room <= 0) continue;
    const pick = list.sort((a, b) => (+a.messageTimestamp || 0) - (+b.messageTimestamp || 0)).slice(-room);
    for (const m of pick) { if (s.hist.n >= HIST_MAX) return; s.hist.n++; s.hist.per.set(chat, (s.hist.per.get(chat) || 0) + 1); if (!m.pushName && !m.key.fromMe) m.pushName = s.hist.names.get(norm(chat)) || ''; await onMessage(s, m, 'history'); }
  }
}
async function onMessage(s, m, type) {
  if (!m?.key?.id || (type !== 'notify' && type !== 'append' && type !== 'history')) return; if (s.seen.has(m.key.id)) return; s.seen.set(m.key.id, 1); s.lastSeen = Date.now();
  const chat = m.key.remoteJid || ''; if (chat === 'status@broadcast' || /@(newsletter|broadcast)$/.test(chat)) return;
  const c = contentOf(m); if (!c || c.type === 'protocol') return;
  if (c.media) { s.store.set(m.key.id, m); s.auth?.extra?.write('m_' + m.key.id, m).catch(() => {}); } else s.store.set(m.key.id, { key: m.key, message: m.message }); // (a file's keys kept three days: Dar fetches it later, even after a restart)
  const isGroup = /@g\.us$/.test(chat); const fromMe = !!m.key.fromMe;
  let peer = norm(isGroup ? (m.key.participantAlt || m.key.participant || '') : (m.key.remoteJidAlt || chat));
  if (/@lid$/.test(peer)) peer = await pnOf(s, peer);
  const lidOnly = /@lid$/.test(peer); if (lidOnly && !isGroup) { const d = peer.split('@')[0]; if (!s.lids.has(d)) { s.lids.add(d); saveLids(s); } }
  const chatJid = isGroup ? chat : peer; const meJid = s.me?.id || ''; const meLid = s.me?.lid ? norm(s.me.lid) : '';
  const self = !isGroup && fromMe && (chatJid === meJid || (meLid !== '' && (norm(chat) === meLid || chatJid === meLid)));
  const byApi = fromMe && s.sent.has(m.key.id); // (what Dar sent through this session: marked before it left)
  await emit(s.sid, 'message.in', {
    id: m.key.id, chat: chatJid, chat_raw: chat, from: fromMe ? (s.me?.phone || '') : (digitsOf(peer) || peer), from_jid: fromMe ? meJid : peer, lid: !fromMe && lidOnly, name: m.pushName || '', from_me: fromMe, self, by_api: byApi, group: isGroup, group_id: isGroup ? chat : '',
    to: fromMe ? (digitsOf(chatJid) || chatJid) : (s.me?.phone || ''), at: (+m.messageTimestamp || Math.floor(Date.now() / 1000)) * 1000, kind: type, ...(type === 'history' ? { history: true, chat_name: s.hist?.names.get(norm(chat)) || '' } : {}), ...c,
  }, evId(s.sid, 'in', m.key.id));
}
const ACK = { 0: 'failed', 1: 'pending', 2: 'sent', 3: 'delivered', 4: 'read', 5: 'read' };
function onUpdate(s, u) {
  const st = u?.update?.status; if (st == null || !u.key?.id || !u.key.fromMe) return; const v = ACK[st]; if (!v || v === 'pending') return;
  emit(s.sid, 'message.status', { id: u.key.id, chat: u.key.remoteJid, status: v, at: Date.now() }, evId(s.sid, 'st', u.key.id + ':' + v));
}
// a vote on a poll this session sent: who chose what now (a vote changed replaces the one before; nothing chosen = taken back)
async function onPoll(s, u) {
  const id = u.key?.id; if (!id || !getAggregateVotesInPollMessage) return;
  const creation = s.sent.get(id)?.message || (await s.auth?.extra?.read('p_' + id).catch(() => null))?.message; if (!creation) return;
  let agg = []; try { agg = getAggregateVotesInPollMessage({ message: creation, pollUpdates: u.update.pollUpdates }, s.me?.id) || []; } catch (e) { log(s.sid, 'poll', e.message); return; }
  const who = j => digitsOf(norm(String(j || ''))) || String(j || '').split('@')[0].split(':')[0];
  const by = new Map(); for (const o of agg) for (const v of o.voters || []) { const d = who(v); if (!by.has(d)) by.set(d, []); by.get(d).push(String(o.name || '')); }
  for (const pu of u.update.pollUpdates) { const k = pu.pollUpdateMessageKey || {}; const d = who(k.participant || k.remoteJid); if (d && !by.has(d)) by.set(d, []); }
  const at = Date.now();
  for (const [voter, options] of by) { if (!voter) continue; emit(s.sid, 'poll.vote', { id, chat: u.key.remoteJid || '', voter, options, at }, evId(s.sid, 'pv', id + ':' + voter + ':' + at)); }
}

// ---------------------------------------------------------------- sending (one at a time per session, paced; a daily cap against bans)
const today = () => new Date().toISOString().slice(0, 10);
const pause = ms => new Promise(r => setTimeout(r, ms));
async function mediaOf(x) {
  if (x.data) return Buffer.from(String(x.data), 'base64');
  if (x.url && /^https:\/\//.test(x.url)) { const r = await fetch(x.url, { signal: AbortSignal.timeout(30e3) }); if (!r.ok) throw new Error('media: HTTP ' + r.status); const b = Buffer.from(await r.arrayBuffer()); if (b.length > 64 * 1024 * 1024) throw new Error('media too large'); return b; }
  throw Object.assign(new Error('media: url (https) or data required'), { code: 400 });
}
async function send(s, p) {
  if (s.status !== 'open' && s.me && ['connecting', 'reconnecting', 'starting'].includes(s.status)) for (let i = 0; i < 80 && s.status !== 'open'; i++) await pause(250); // (a short drop: the message waits for the connection)
  if (s.status !== 'open' || !s.sock) throw Object.assign(new Error('not linked'), { code: 409 });
  const jid = jidFor(s, p.to); if (!jid) throw Object.assign(new Error('to'), { code: 400 });
  if (p.key && s.sent.has('k:' + p.key)) return s.sent.get('k:' + p.key).res; // (the same request twice: sent once)
  if (s.day.d !== today()) s.day = { d: today(), n: 0 }; if (s.day.n >= DAILY_CAP) throw Object.assign(new Error('daily cap reached'), { code: 429 });
  const t = String(p.type || 'text'); let content;
  if (t === 'text') { const text = String(p.text || '').slice(0, 65000); if (!text.trim()) throw Object.assign(new Error('text'), { code: 400 }); content = { text }; }
  else if (t === 'image') content = { image: await mediaOf(p), caption: String(p.caption || '') };
  else if (t === 'video') content = { video: await mediaOf(p), caption: String(p.caption || '') };
  else if (t === 'audio' || t === 'voice') content = { audio: await mediaOf(p), mimetype: p.mime || 'audio/ogg; codecs=opus', ptt: t === 'voice' };
  else if (t === 'document') content = { document: await mediaOf(p), mimetype: p.mime || 'application/octet-stream', fileName: String(p.filename || 'file'), caption: String(p.caption || '') };
  else if (t === 'location') content = { location: { degreesLatitude: +p.lat, degreesLongitude: +p.lng, name: String(p.name || ''), address: String(p.address || '') } };
  else if (t === 'contact') content = { contacts: { displayName: String(p.name || ''), contacts: [{ vcard: String(p.vcard || '') }] } };
  else if (t === 'reaction') content = { react: { text: String(p.text || ''), key: { remoteJid: jid, id: String(p.target || ''), fromMe: !!p.target_from_me } } };
  else if (t === 'poll') { const values = [...new Set((p.options || []).map(x => String(x).trim()).filter(Boolean))].slice(0, 12); if (!String(p.text || '').trim() || values.length < 2) throw Object.assign(new Error('poll: a question and two options'), { code: 400 }); content = { poll: { name: String(p.text).slice(0, 255), values, selectableCount: p.multi ? 0 : 1 } }; } // (0: as many answers as one likes)
  else throw Object.assign(new Error('type'), { code: 400 });
  const opts = {}; if (p.quoted?.id) { const q = s.store.get(p.quoted.id); if (q) opts.quoted = q; }
  const run = async () => {
    const gap = Date.now() - (s.lastSend || 0); const want = 1200 + Math.floor(Math.random() * 1800); if (gap < want) await pause(want - gap);
    if (p.typing && t === 'text') { try { await s.sock.sendPresenceUpdate('composing', jid); await pause(Math.min(4000, 400 + content.text.length * 25)); await s.sock.sendPresenceUpdate('paused', jid); } catch { /* typing is a courtesy */ } }
    const messageId = generateMessageIDV2 ? generateMessageIDV2(s.sock.user?.id) : undefined; if (messageId) s.sent.set(messageId, { message: undefined }); // (its echo is known as Dar's own)
    const r = await s.sock.sendMessage(jid, content, messageId ? { ...opts, messageId } : opts); s.lastSend = Date.now(); s.day.n++;
    const id = r?.key?.id || ''; if (id) s.sent.set(id, { message: r.message }); const res = { id, to: digitsOf(jid) || jid, at: Date.now() };
    if (t === 'poll' && id) s.auth?.extra?.write('p_' + id, { key: r.key, message: r.message }).catch(() => {}); // (its votes come later, maybe after a restart)
    if (p.key) s.sent.set('k:' + p.key, { res }); return res;
  };
  const job = s.queue.then(run, run); s.queue = job.catch(() => {}); return job;
}

// a WhatsApp Status (a story): seen by the numbers given (the people who saved this number see it), in the same paced line
async function story(s, p) {
  if (s.status !== 'open' || !s.sock) throw Object.assign(new Error('not linked'), { code: 409 });
  if (p.key && s.sent.has('k:' + p.key)) return s.sent.get('k:' + p.key).res;
  const list = [...new Set((Array.isArray(p.to) ? p.to : []).map(x => jidFor(s, x)).filter(j => /@(s\.whatsapp\.net|lid)$/.test(j)))].slice(0, 2000);
  if (!list.length) throw Object.assign(new Error('audience: the numbers who will see it'), { code: 400 });
  if (s.day.d !== today()) s.day = { d: today(), n: 0 }; if (s.day.n >= DAILY_CAP) throw Object.assign(new Error('daily cap reached'), { code: 429 });
  const t = String(p.type || 'text'); let content; const opts = { statusJidList: list, broadcast: true };
  if (t === 'text') { const text = String(p.text || '').slice(0, 700); if (!text.trim()) throw Object.assign(new Error('text'), { code: 400 }); content = { text }; opts.backgroundColor = /^#[0-9a-f]{6}$/i.test(String(p.bg || '')) ? p.bg : '#0f5132'; opts.font = Math.max(0, Math.min(5, Math.round(+p.font || 0))); }
  else if (t === 'image') content = { image: await mediaOf(p), caption: String(p.caption || '').slice(0, 700) };
  else if (t === 'video') content = { video: await mediaOf(p), caption: String(p.caption || '').slice(0, 700) };
  else throw Object.assign(new Error('type'), { code: 400 });
  const run = async () => {
    const gap = Date.now() - (s.lastSend || 0); const want = 1200 + Math.floor(Math.random() * 1800); if (gap < want) await pause(want - gap);
    const r = await s.sock.sendMessage('status@broadcast', content, opts); s.lastSend = Date.now(); s.day.n++;
    const res = { id: r?.key?.id || '', to: list.length, at: Date.now() }; if (r?.key?.id) s.sent.set(r.key.id, { message: r.message }); if (p.key) s.sent.set('k:' + p.key, { res }); return res;
  };
  const job = s.queue.then(run, run); s.queue = job.catch(() => {}); return job;
}

// ---------------------------------------------------------------- Dar's minute: a signed «tick» each minute while a number is linked
// (Dar sends its scheduled messages and its campaigns' next few on it — to the minute, without waiting for its host's scheduled job)
const TICK_DAR = Math.max(5e3, +(env.GW_DAR_TICK_MS || 60e3));
async function tickDar() {
  if (!RUNNER || !HOOK || !SECRET) return; const open = [...S.values()].filter(x => x.status === 'open').length; if (!open) return;
  const body = JSON.stringify({ id: 'tick-' + Math.floor(Date.now() / TICK_DAR), sid: '_', type: 'tick', data: { open }, at: Date.now(), v: VERSION }); const u = new URL(HOOK);
  try { await fetch(HOOK, { method: 'POST', headers: { 'Content-Type': 'application/json', ...signHeaders(SECRET, 'POST', u.pathname + u.search, body) }, body, signal: AbortSignal.timeout(20e3) }); } catch { /* the next minute */ }
}

// ---------------------------------------------------------------- HTTP: Dar's requests, signed
const nonces = new Map(); setInterval(() => { const t = Date.now(); for (const [k, v] of nonces) if (v < t) nonces.delete(k); }, 60e3).unref();
function verify(req, body) {
  const ts = +req.headers['x-dar-ts'] || 0; const nonce = String(req.headers['x-dar-nonce'] || ''); const sig = String(req.headers['x-dar-sig'] || '');
  if (!ts || Math.abs(Date.now() / 1000 - ts) > 300 || !/^[a-f0-9]{16,64}$/.test(nonce) || !/^[a-f0-9]{64}$/.test(sig) || nonces.has(nonce)) return false;
  const u = new URL(req.url, 'http://x'); const h = createHash('sha256').update(body || '').digest('hex');
  const want = createHmac('sha256', SECRET).update(`${ts}.${nonce}.${req.method}.${u.pathname}${u.search}.${h}`).digest();
  const got = Buffer.from(sig, 'hex'); if (got.length !== want.length || !timingSafeEqual(got, want)) return false;
  nonces.set(nonce, Date.now() + 600e3); return true;
}
const json = (res, code, data) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(data)); };
let pairs = []; // (the pairing asked at most 6 times an hour)
// a signed request reaching a process that is not the runner: handed to the runner as it came, through the data folder (the runner
// checks the signature); its answer comes back the same way
const RKEY = createHash('sha256').update(Buffer.concat([MASTER, Buffer.from('rpc')])).digest();
async function forward(req, res, body) {
  if (!HOLDER) { await claimRunner().catch(() => {}); if (RUNNER) { await restoreAll().catch(() => {}); return false; } }
  if (!HOLDER) return json(res, 503, { error: 'no runner yet', retry: true }), true;
  await mkdir(RPC, { recursive: true, mode: 0o700 }); const id = Date.now() + '-' + randomBytes(8).toString('hex'); const rq = join(RPC, id + '.req'), rs = join(RPC, id + '.res');
  const msg = { method: req.method, url: req.url, headers: { 'content-type': req.headers['content-type'] || 'application/json', 'x-dar-ts': req.headers['x-dar-ts'] || '', 'x-dar-nonce': req.headers['x-dar-nonce'] || '', 'x-dar-sig': req.headers['x-dar-sig'] || '' }, body, at: Date.now() };
  const tmp = rq + '.tmp'; await writeFile(tmp, seal(RKEY, JSON.stringify(msg)), { mode: 0o600 }); await rename(tmp, rq);
  for (let t0 = Date.now(); Date.now() - t0 < 120e3;) {
    let raw = null; try { raw = await readFile(rs, 'utf8'); } catch { /* not yet */ }
    if (raw !== null) {
      await unlink(rs).catch(() => {}); let a; try { a = JSON.parse(open(RKEY, raw)); } catch { return json(res, 502, { error: 'runner answer' }), true; }
      const h = { 'Content-Type': a.type || 'application/json', 'Cache-Control': 'no-store' }; if (a.filename) h['X-Filename'] = a.filename;
      res.writeHead(a.status || 200, h); res.end(Buffer.from(a.body || '', 'base64')); return true;
    }
    if (Date.now() - t0 > 4000 && !(await stat(rq).then(() => true, () => false)) && !(await stat(rq.replace(/\.req$/, '.work')).then(() => true, () => false)) && !(await stat(rs).then(() => true, () => false))) break; // (taken and lost)
    if (Date.now() - t0 > 8000 && (await stat(rq).then(() => true, () => false))) { const cur = await readJson(LOCK); if (!cur || Date.now() - (+cur.at || 0) >= STALE) { await unlink(rq).catch(() => {}); HOLDER = null; return json(res, 503, { error: 'runner unreachable', retry: true }), true; } } // (nobody takes it: the runner is gone)
    await pause(40);
  }
  await unlink(rq).catch(() => {}); return json(res, 504, { error: 'runner timeout', retry: true }), true;
}
// the runner: the requests the other processes left, answered in the same way as its own
// v1.1.1: each request on its own — a slow one (a Telegram call) never holds the others back (live, 2026-11-06: while the Telegram account
// was linking, WhatsApp's requests through the other processes waited behind it and Dar's calls timed out)
let rpcBusy = false; const rpcFlight = new Set();
async function rpcServe() {
  if (!RUNNER || rpcBusy) return; rpcBusy = true;
  try {
    let names = []; try { names = (await readdir(RPC)).filter(x => x.endsWith('.req') && !rpcFlight.has(x)); } catch { return; }
    for (const x of names) rpcFlight.add(x);
    names.map(async name => { try {
      const rq = join(RPC, name), wk = rq.replace(/\.req$/, '.work'), rs = rq.replace(/\.req$/, '.res');
      try { await rename(rq, wk); } catch { return; } // (another runner took it — or nobody: it is gone)
      let msg; try { msg = JSON.parse(open(RKEY, await readFile(wk, 'utf8'))); } catch { await unlink(wk).catch(() => {}); return; }
      if (Date.now() - (+msg.at || 0) > 120e3) { await unlink(wk).catch(() => {}); return; }
      const out = await new Promise(resolve => {
        const fake = { method: msg.method, url: msg.url, headers: msg.headers || {}, async *[Symbol.asyncIterator]() { if (msg.body) yield msg.body; } };
        let st = 200, hd = {}; const fres = { writeHead(c, h) { st = c; hd = h || {}; }, end(b) { resolve({ status: st, type: hd['Content-Type'] || 'application/json', filename: hd['X-Filename'] || '', body: Buffer.from(b == null ? '' : b).toString('base64') }); } };
        handler(true)(fake, fres).catch(e => resolve({ status: 500, type: 'application/json', body: Buffer.from(JSON.stringify({ error: String(e.message || e) })).toString('base64') }));
      });
      const tmp = rs + '.tmp'; await writeFile(tmp, seal(RKEY, JSON.stringify(out)), { mode: 0o600 }); await rename(tmp, rs); await unlink(wk).catch(() => {});
    } finally { rpcFlight.delete(name); } });
    // (what nobody collected after two minutes is removed)
    for (const x of await readdir(RPC).catch(() => [])) { const at = +String(x).split('-')[0]; if (at && Date.now() - at > 180e3) await unlink(join(RPC, x)).catch(() => {}); }
  } finally { rpcBusy = false; }
}
const handler = internal => async (req, res) => {
  let body = ''; for await (const c of req) { body += c; if (body.length > 70 * 1024 * 1024) { json(res, 413, { error: 'too large' }); return; } }
  const u = new URL(req.url, 'http://x'); const path = u.pathname.replace(/\/+$/, '') || '/'; let p = {}; try { p = body ? JSON.parse(body) : {}; } catch { return json(res, 400, { error: 'json' }); }
  try {
    if (path === '/' || path === '/health') {
      const all = [...S.values()]; const h = RUNNER ? null : (HOLDER || await readJson(LOCK)); const age = h ? Math.round((Date.now() - (+h.at || 0)) / 1000) : null;
      return json(res, 200, { ok: true, service: 'dar-wa-gateway', v: VERSION, tg: TG ? TG.sessions().map(x => x.status) : [], up: Math.round(process.uptime()), runner: RUNNER, boot: BOOT, pid: process.pid, holder: RUNNER ? null : h ? { pid: h.pid, v: h.v, age, same_host: h.host === ME.host, alive: age !== null && age * 1000 < STALE && pidAlive(h.pid, h.host) } : null, sessions: { total: all.length, open: all.filter(s => s.status === 'open').length }, outbox: { pending: outbox.status().pending, last_ok: outbox.status().last_ok } });
    }
    // the pairing: the secret is sent to Dar's own address only (DAR_ORIGIN), with the nonce Dar made — never in this answer
    if (path === '/v1/pair' && req.method === 'POST') {
      pairs = pairs.filter(t => Date.now() - t < 3600e3); if (pairs.length >= 6) return json(res, 429, { error: 'too many' }); pairs.push(Date.now());
      const nonce = String(p.nonce || ''); if (!/^[a-f0-9]{32,64}$/.test(nonce) || !PAIR_HOOK) return json(res, 400, { error: 'nonce' });
      const r = await fetch(PAIR_HOOK, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nonce, secret: SECRET, gateway: env.PUBLIC_URL || '', v: VERSION }), signal: AbortSignal.timeout(20e3) }).catch(e => ({ status: 0, e }));
      const sent = r.status >= 200 && r.status < 300; if (sent) setTimeout(() => outbox.now(), 300); // (what waited for Dar's pairing leaves now)
      return json(res, 200, { sent, status: r.status || 0 });
    }
    if (FAKE && path.startsWith('/__fake/tg/')) { const g = await tg(); return g ? (await import('./test/fake-telegram.mjs')).fakeRoute(path, p, { TG: g, json: (c, d) => json(res, c, d) }) : json(res, 501, {}); }
    if (FAKE && path.startsWith('/__fake/')) return B.fakeRoute(path, p, { S, json: (c, d) => json(res, c, d), emit });
    if (!RUNNER && !internal && path.startsWith('/v1/')) { if (await forward(req, res, body)) return; }
    if (!verify(req, body)) return json(res, 401, { error: 'signature' });
    if (!RUNNER) return json(res, 503, { error: 'busy', retry: true });
    const tm = path.match(/^\/v1\/tg\/([a-z0-9][a-z0-9_-]{1,63})(?:\/([a-z_]+))?$/); // v1.1.0: the developer's own Telegram account
    if (tm) { const g = await tg(); if (!g) return json(res, 501, { error: 'telegram library missing' }); const [code, data] = await g.handle(req.method, tm[1], tm[2] || '', p, u.searchParams); return json(res, code, data); }
    if (path === '/v1/sessions' && req.method === 'GET') return json(res, 200, { sessions: [...S.values()].map(pub) });
    const m = path.match(/^\/v1\/sessions\/([a-z0-9][a-z0-9_-]{1,63})(?:\/([a-z_]+))?$/); if (!m) return json(res, 404, { error: 'route' });
    const sid = m[1]; const act = m[2] || ''; const s = S.get(sid);
    if (req.method === 'GET' && act === '') return json(res, 200, s ? pub(s) : { sid, status: (await hasCreds(ROOT, sid)) ? 'stopped' : 'none' });
    if (req.method === 'POST' && act === 'start') {
      const x = await startSession(sid, { mode: p.mode === 'code' ? 'code' : 'qr', phone: p.phone || '' });
      for (let i = 0; i < 40 && !['qr', 'code', 'open', 'logged_out', 'banned', 'expired', 'error'].includes(x.status); i++) await pause(250); // (the first QR takes a moment)
      if (p.mode === 'code' && p.phone && x.status === 'qr') await askCode(x, p.phone).catch(e => { x.reason = e.message; });
      return json(res, 200, pub(x));
    }
    if (!s && act !== 'logout') return json(res, 404, { error: 'no session', status: 'none' });
    if (req.method === 'POST' && act === 'logout') {
      if (s?.sock) { try { await s.sock.logout(); } catch { /* the phone may be gone already */ } }
      if (s) { s.sock = null; setStatus(s, 'logged_out', 'unlinked from Dar'); S.delete(sid); } await retire(ROOT, sid); return json(res, 200, { ok: true });
    }
    if (req.method === 'POST' && act === 'send') return json(res, 200, await send(s, p));
    if (req.method === 'POST' && act === 'story') return json(res, 200, await story(s, p));
    if (req.method === 'POST' && act === 'presence') { await s.sock?.sendPresenceUpdate(['composing', 'recording', 'paused', 'available', 'unavailable'].includes(p.state) ? p.state : 'composing', p.to ? jidFor(s, p.to) : undefined); return json(res, 200, { ok: true }); }
    if (req.method === 'POST' && act === 'read') { const keys = (p.keys || []).map(k => ({ remoteJid: jidFor(s, k.chat || k.remoteJid), id: String(k.id), participant: k.participant || undefined, fromMe: false })).filter(k => k.remoteJid && k.id); await s.sock?.readMessages(keys); return json(res, 200, { ok: true, n: keys.length }); }
    if (req.method === 'POST' && act === 'check') { const nums = (p.numbers || []).map(toJid).filter(Boolean).slice(0, 50); const r = nums.length ? await s.sock.onWhatsApp(...nums) : []; return json(res, 200, { results: (r || []).map(x => ({ number: digitsOf(x.jid), exists: !!x.exists })) }); }
    if (act === 'contacts') { // v1.0.6: GET ?q=<name or number>&text=<a message>&limit= · POST {action:'sync'}
      if (!s.contacts) return json(res, 200, { ok: true, items: [], total: 0, synced: false });
      let sync = null; if (req.method === 'POST' && p.action === 'sync') sync = await syncContacts(s, true);
      else if (!s.contacts.st.syncedAt && !s.contacts.size && s.status === 'open' && !s.csync) syncContacts(s).catch(() => {}); // (never asked yet: it starts now, the answer after it)
      const st = s.contacts.stats();
      return json(res, 200, { ok: true, ...st, synced: st.synced_at > 0 || st.total > 0, syncing: !!s.csync, items: s.contacts.search({ q: String(u.searchParams.get('q') ?? p.q ?? ''), text: String(u.searchParams.get('text') ?? p.text ?? ''), limit: +(u.searchParams.get('limit') ?? p.limit ?? 8) }), ...(sync ? { sync } : {}) });
    }
    if (req.method === 'GET' && act === 'groups') { const g = await s.sock.groupFetchAllParticipating(); return json(res, 200, { groups: Object.values(g || {}).map(x => ({ id: x.id, subject: x.subject, size: (x.participants || []).length })) }); }
    if (req.method === 'POST' && act === 'chat') {
      const jid = jidFor(s, p.chat); const last = s.store.keys().reverse().map(k => s.store.get(k)).find(x => x?.key?.remoteJid === jid);
      const mod = p.action === 'archive' || p.action === 'unarchive' ? { archive: p.action === 'archive', lastMessages: last ? [last] : [] } : p.action === 'pin' || p.action === 'unpin' ? { pin: p.action === 'pin' } : p.action === 'mute' ? { mute: Date.now() + (+p.hours || 8) * 3600e3 } : p.action === 'unmute' ? { mute: null } : null;
      if (!mod) return json(res, 400, { error: 'action' }); await s.sock.chatModify(mod, jid); return json(res, 200, { ok: true });
    }
    if (req.method === 'POST' && act === 'block') { await s.sock.updateBlockStatus(jidFor(s, p.chat), p.action === 'unblock' ? 'unblock' : 'block'); return json(res, 200, { ok: true }); }
    if (req.method === 'POST' && act === 'picture') { const url = await s.sock.profilePictureUrl(jidFor(s, p.chat), 'image').catch(() => ''); return json(res, 200, { url: url || '' }); }
    if (req.method === 'GET' && act === 'media') {
      const mid = String(u.searchParams.get('id') || ''); const m2 = s.store.get(mid)?.message ? s.store.get(mid) : (/^[A-Za-z0-9_.:-]{4,120}$/.test(mid) ? await s.auth?.extra?.read('m_' + mid) : null); if (!m2?.message) return json(res, 404, { error: 'media gone' });
      const buf = await downloadMediaMessage(m2, 'buffer', {}, { logger: silent, reuploadRequest: s.sock?.updateMediaMessage });
      const c = contentOf(m2) || {}; res.writeHead(200, { 'Content-Type': c.mime || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Filename': encodeURIComponent(c.filename || '') }); return res.end(buf);
    }
    return json(res, 404, { error: 'route' });
  } catch (e) { return json(res, e.code >= 400 && e.code < 600 ? e.code : 500, { error: String(e.message || e).slice(0, 300) }); }
};
const server = http.createServer(handler(false));

// ---------------------------------------------------------------- staying up
async function boot() {
  BOOT = 'starting'; await mkdir(RPC, { recursive: true, mode: 0o700 });
  if (await claimRunner()) await restoreAll(); else log('another process runs the sessions; this one hands requests to it');
  try { watch(RPC, () => { rpcServe().catch(() => {}); }).on('error', () => {}); } catch { /* the slower round below */ }
  setInterval(() => { rpcServe().catch(() => {}); }, 150).unref();
  setInterval(() => { runnerTick().catch(e => log('runner', e.message)); }, TICK).unref();
  setInterval(() => { tickDar().catch(() => {}); }, TICK_DAR).unref();
  setInterval(() => { cleanTrash(ROOT).catch(() => {}); for (const s of S.values()) { s.auth?.extra?.prune('m_', 3).catch(() => {}); s.auth?.extra?.prune('p_', 45).catch(() => {}); if (s.status === 'expired' && Date.now() - s.since > 3600e3) S.delete(s.sid); } }, 3600e3).unref();
  // the host may put a quiet app to sleep: its own public address is asked every four minutes (Dar's scheduled job asks too)
  if (env.PUBLIC_URL) setInterval(() => { fetch(env.PUBLIC_URL.replace(/\/+$/, '') + '/health', { signal: AbortSignal.timeout(15e3) }).catch(() => {}); }, 240e3).unref();
  BOOT = 'ready';
}
process.on('unhandledRejection', e => log('unhandled', e?.message || e));
process.on('uncaughtException', e => log('uncaught', e?.message || e));
const stop = async () => { try { await standDown('stopped'); } catch { /* closing */ } process.exit(0); };
process.on('SIGTERM', stop); process.on('SIGINT', stop);
server.on('error', e => { log('listen', e.message); if (e.code === 'EADDRINUSE') process.exit(1); }); // (a process that cannot serve does not linger)
server.listen(+(env.PORT || 3000), env.HOST || undefined, () => { log('dar-wa-gateway', VERSION, 'on', server.address().port, FAKE ? '(fake WhatsApp)' : ''); boot().catch(e => { BOOT = 'error: ' + String(e.message || e).slice(0, 120); log('boot', e.message); }); });
export { server };
