# بوابة واتساب لدار · Dar WhatsApp gateway

تطبيق Node.js صغير يربط أرقام واتساب بدار عبر **مسح رمز QR** أو **رمز من ثمانية أحرف**، دون حساب لدى Meta ودون رسوم على الرسائل.
رقم المطوّر (من «التحكم عبر واتساب») وأرقام المكاتب (من «التكاملات») — لكل حساب جلسة مستقلة معزولة.

A small Node.js app that links WhatsApp numbers to Dar by **scanning a QR code** or typing an **eight-letter code** — no Meta account, no per-message fee. The developer's own number (from «WhatsApp control») and each office's (from «Integrations»), one isolated session per account.

## كيف يعمل · How it works

- **WhatsApp Web multi-device** through [Baileys](https://github.com/WhiskeySockets/Baileys) `7.0.0-rc14` (pinned). Each session's keys are **sealed at rest** (AES-256-GCM, a key per session derived from `GW_MASTER_KEY` with HKDF), written atomically, never logged.
- **Dar ↔ gateway, signed both ways**: HMAC-SHA256 over `ts.nonce.METHOD.path.sha256(body)`, five minutes' grace, each nonce once. The shared secret reaches Dar by a **pairing only Dar's own address can complete** (`POST /v1/pair` → the gateway sends its secret to `DAR_ORIGIN/dar-sync.php?wag=pair` with Dar's nonce) — it is never shown in a browser or a link.
- **Nothing is lost**: every event (a message in, a delivery report, a link made or lost) is written to a sealed outbox on disk, then delivered to Dar in order until Dar answers — a restart or Dar being down for an hour loses nothing; Dar takes each event once.
- **It stays up**: linked sessions come back by themselves after a restart; a dropped connection is reopened with growing waits (a drop under a minute is not even reported); a message sent during a short drop waits for the connection; a logged-out session's keys are kept aside seven days (never deleted on a failure); the gateway asks its own public address every four minutes (a host that idles quiet apps keeps it awake) and Dar's scheduled job asks it too.
- **Against bans**: one message at a time per number, 1.2–3 s apart, optional typing, a daily cap per number (`GW_DAILY_CAP`, default 1000), the same request (its `key`) sent once.

## التشغيل على Hostinger · Running on Hostinger

1. موقع جديد من نوع Node.js على نطاق فرعي، مثل `wa.dar.ink` (لا تنشره على موقع دار نفسه: البناء يستبدل محتوى الموقع).
   A new Node.js website on a subdomain such as `wa.dar.ink` (never on Dar's own website: a build replaces the site's contents).
2. ارفع محتوى هذا المجلد (دون `node_modules`)، نقطة الدخول `server.mjs`، Node 22.
   Upload this folder (without `node_modules`), entry `server.mjs`, Node 22.
3. متغيرات البيئة · Environment variables:

| Variable | |
|---|---|
| `DAR_ORIGIN` | `https://dar.ink` — Dar's address (the only place the secret is ever sent) |
| `PUBLIC_URL` | `https://wa.dar.ink` — this gateway's own address (its keep-awake ping) |
| `GW_MASTER_KEY` | 32 random bytes, base64 (`openssl rand -base64 32`) — seals the sessions; keep it: without it the sessions must be scanned again |
| `GW_DATA_DIR` | optional — default `~/.dar-wa` (outside the website folder, so a rebuild keeps the sessions) |
| `GW_DAILY_CAP` | optional — messages a number may send a day (default 1000) |
| `GW_SECRET` | optional — otherwise made once and kept in `GW_DATA_DIR/_secret` |
| `GW_DAR_TICK_MS` | optional — Dar's minute (default 60000) |

4. في دار: «الربط والمفاتيح» ← «بوابة واتساب» ← ضع عنوانها واحفظ — تقترن دار بها تلقائيًا. ثم «التحكم عبر واتساب» ← «اعرض رمز الربط» وامسحه من هاتفك.
   In Dar: «Links & keys» → «WhatsApp gateway» → its address → save (Dar pairs by itself). Then «WhatsApp control» → «Show the link code» and scan it with your phone.

## الواجهة · API (all `/v1/*` calls signed)

`GET /health` (no secret) · `POST /v1/pair {nonce}` · `GET /v1/sessions` · `GET /v1/sessions/:sid` · `POST /v1/sessions/:sid/start {mode: qr|code, phone}` · `POST …/logout` · `POST …/send {to, type: text|image|video|audio|voice|document|location|contact|reaction|poll, text, url|data, caption, filename, mime, quoted:{id}, options, multi, target, key, typing}` · `POST …/story {type: text|image|video, text, bg, font, data|url, caption, to: [numbers], key}` (a WhatsApp Status for those numbers) · `POST …/presence` · `POST …/read` · `POST …/check {numbers}` · `GET …/groups` · `POST …/chat {chat, action: archive|unarchive|pin|unpin|mute|unmute}` · `POST …/block` · `POST …/picture` · `GET …/media?id=`

**جهات الاتصال · Contacts (v1.0.6)**: the gateway keeps the phone's address book (the saved names WhatsApp gives a linked device, sealed on disk like the session) and answers `GET /v1/sessions/:sid/contacts?q=<name or number>&text=<a message>&limit=` (the people whose name matches / whom the message mentions: `{items:[{phone,name,shown}], total, synced}`) and `POST …/contacts {action:"sync"}` (asks the phone for the whole book again). A session asks once, 25 seconds after it opens, and again after a week. Dar's assistant searches them by name (so «أرسل إلى مرام» finds her number), and never sends to a number that is not in them, in Dar's records or in the owner's own words.

Events to Dar (`POST DAR_ORIGIN/dar-sync.php?wag=1`, signed): `session.status`, `message.in` (with `self` for one's own chat, `by_api` for Dar's own sends, `lid` for a person WhatsApp shows only by his private id), `message.status`, `poll.vote` (who chose what on a poll the session sent — a changed vote replaces the one before), `reaction`, `call`; and, while a number is linked, a signed `tick` each minute (`GW_DAR_TICK_MS`, default 60000) on which Dar sends its scheduled messages and its campaigns' next few — to the minute, without waiting for its host's scheduled job (never kept in the outbox: a missed minute is simply the next one).

## حسابك في تيليجرام · Your Telegram account (1.1.0)

تربط البوابة أيضًا **حساب مطوّر دار نفسه في تيليجرام** (ليس بوتًا) بمسح رمز من تيليجرام: الإعدادات ← الأجهزة ← ربط جهاز سطح المكتب. بعد الربط يدخل مساعده المجموعات برابط الدعوة، ويقرأ محادثاته ويكتب فيها باسمه، ويشارك وحده حيث يسمح له. جلسة واحدة فقط: `platform`.

The gateway also links **Dar's developer's own Telegram account** (not a bot) by scanning a code from Telegram: Settings → Devices → Link Desktop Device. Once linked, his assistant joins groups by their invite links, reads his chats, writes in them as him, and takes part by itself where he lets it. One session only: `platform`.

- [teleproto](https://www.npmjs.com/package/teleproto) `1.232.0` (pinned; the maintained fork of GramJS). The string session and the app's keys are **sealed at rest** like the WhatsApp sessions (`GW_DATA_DIR/_tg/platform.enc`, a key of their own from `GW_MASTER_KEY`), and the account comes back by itself after a restart.
- **The app's keys**: my.telegram.org → API development tools → create an app → `api_id`, `api_hash` — saved in Dar («الربط والمفاتيح» → «حسابك في تيليجرام»), sent by Dar with the start call; never in this code.
- **Two-step verification**: the password is typed in Dar's panel and goes to Telegram only — never written, never logged.
- One message at a time, at least 2 s apart, a daily cap (`GW_TG_DAILY_CAP`, default 300), Telegram's own `FLOOD_WAIT` honoured (429 with `retry_after`).

`GET /v1/tg/platform` (`{status: none|starting|qr|password|open|expired|error|logged_out, qr: "tg://login?token=…", hint, me:{id,username,name,phone}, reason}`) · `POST …/start {api_id, api_hash}` · `POST …/password {password}` · `POST …/logout` · `POST …/send {chat, text, reply_to, key, typing}` (chat: an id, `@name` or a t.me link) · `POST …/join {link}` (`t.me/+…`, `t.me/joinchat/…`, `t.me/name`) · `GET …/dialogs?limit=` · `GET …/history?chat=&limit=` · `POST …/typing {chat}`

Events to Dar: `tg.status` (`{status, reason, me}`) and `tg.message.in` (`{chat:{id,title,type,username}, id, date, text, out, by_api, from:{id,name,username,bot}, reply_to, mentioned, reply_to_me}`).

## الاختبار · Tests

`node test/tg.mjs` (the Telegram account against its stand-in, `test/fake-telegram.mjs`) · `node tests/sync-wa.mjs` (from Dar's package) runs Dar and this gateway together against a stand-in of WhatsApp (`test/fake-baileys.mjs`, `GW_FAKE=1` — never in production).
